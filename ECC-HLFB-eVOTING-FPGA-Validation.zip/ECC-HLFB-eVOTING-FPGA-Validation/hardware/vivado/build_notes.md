# Vivado build notes (reference)

## AXI GPIO interface (PS<->PL)

### PS->PL input mask (8-bit)
bit0 cert_ok  
bit1 sig_ok  
bit2 time_ok  
bit3 nonce_ok  
bit4 fmt_ok  
bit5 ep_ok  
bit6 start (pulse)  
bit7 reserved  

### PL->PS output mask (8-bit)
bit0 accept  
bit1..bit4 rec[3:0]  
bit5 done  
bit6..bit7 reserved  

## Steps
1) Create Block Design (Zynq PS + AXI GPIO)
2) Add/Wrap RTL (`validator_core.v`)
3) Connect GPIO to RTL ports
4) Generate bitstream
5) Export hardware (XSA) to Vitis
6) Boot Linux on board and run `software/vitis_app/validator_app`
