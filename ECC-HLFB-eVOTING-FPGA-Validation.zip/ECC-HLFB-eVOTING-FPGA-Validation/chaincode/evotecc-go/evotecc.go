package main

import (
  "encoding/json"
  "fmt"
  "time"
  "github.com/hyperledger/fabric-contract-api-go/contractapi"
)

type SmartContract struct{ contractapi.Contract }

type Vote struct {
  VoterID    string `json:"voterId"`
  TxID       string `json:"txId"`
  BallotHash string `json:"ballotHash"`
  TS         int64  `json:"ts"`
}

type RejectLog struct {
  VoterID string `json:"voterId"`
  TxID    string `json:"txId"`
  Reason  string `json:"reason"`
  TS      int64  `json:"ts"`
}

func (s *SmartContract) SubmitVote(ctx contractapi.TransactionContextInterface, voterId, txId, ballotHash, tsStr string) error {
  key := fmt.Sprintf("VOTE_%s_%s", voterId, txId)
  v := Vote{VoterID: voterId, TxID: txId, BallotHash: ballotHash, TS: time.Now().Unix()}
  b, _ := json.Marshal(v)
  return ctx.GetStub().PutState(key, b)
}

func (s *SmartContract) LogReject(ctx contractapi.TransactionContextInterface, voterId, txId, reason, tsStr string) error {
  key := fmt.Sprintf("REJ_%s_%s", voterId, txId)
  r := RejectLog{VoterID: voterId, TxID: txId, Reason: reason, TS: time.Now().Unix()}
  b, _ := json.Marshal(r)
  return ctx.GetStub().PutState(key, b)
}

func main() {
  cc, err := contractapi.NewChaincode(new(SmartContract))
  if err != nil { panic(err) }
  if err := cc.Start(); err != nil { panic(err) }
}
