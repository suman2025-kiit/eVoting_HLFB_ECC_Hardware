const express = require("express");
const bodyParser = require("body-parser");
const { connect, signers } = require("@hyperledger/fabric-gateway");
const grpc = require("@grpc/grpc-js");
const fs = require("fs");
const crypto = require("crypto");

const app = express();
app.use(bodyParser.json());

// EDIT THESE FOR YOUR FABRIC NETWORK
const MSP_ID = "Org1MSP";
const PEER_ENDPOINT = "peer0.org1.example.com:7051";
const TLS_CERT_PATH = "./crypto/peer0-tls-ca.pem";
const CLIENT_CERT_PATH = "./crypto/user-cert.pem";
const CLIENT_KEY_PATH  = "./crypto/user-key.pem";
const CHANNEL_NAME = "mychannel";
const CHAINCODE_NAME = "evotecc";

function newGrpcConnection() {
  const tlsRootCert = fs.readFileSync(TLS_CERT_PATH);
  const tlsCredentials = grpc.credentials.createSsl(tlsRootCert);
  return new grpc.Client(PEER_ENDPOINT, tlsCredentials, {
    "grpc.ssl_target_name_override": "peer0.org1.example.com",
  });
}

function newIdentity() {
  const credentials = fs.readFileSync(CLIENT_CERT_PATH);
  return { mspId: MSP_ID, credentials };
}

function newSigner() {
  const privateKeyPem = fs.readFileSync(CLIENT_KEY_PATH);
  const privateKey = crypto.createPrivateKey(privateKeyPem);
  return signers.newPrivateKeySigner(privateKey);
}

async function getContract() {
  const client = newGrpcConnection();
  const gateway = connect({ client, identity: newIdentity(), signer: newSigner() });
  const network = gateway.getNetwork(CHANNEL_NAME);
  return network.getContract(CHAINCODE_NAME);
}

app.post("/api/submitVote", async (req, res) => {
  try {
    const { voterId, txId, ballotHash, ts } = req.body;
    const contract = await getContract();
    await contract.submitTransaction("SubmitVote", voterId, txId, ballotHash, String(ts));
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

app.post("/api/logReject", async (req, res) => {
  try {
    const { voterId, txId, reason, ts } = req.body;
    const contract = await getContract();
    await contract.submitTransaction("LogReject", voterId, txId, reason, String(ts));
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

app.listen(8080, () => console.log("Gateway listening on :8080"));
