# Gateway service (Node.js -> Fabric Gateway)

## Endpoints
- `POST /api/submitVote`
- `POST /api/logReject`

## Local crypto (do not commit)
Place the following files inside `software/gateway_service/crypto/`:
- `peer0-tls-ca.pem`
- `user-cert.pem`
- `user-key.pem`

Run:
```bash
cd software/gateway_service
npm install
node server.js
```
