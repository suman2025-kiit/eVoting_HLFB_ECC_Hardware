#include "fpga_mmio.h"
#include <fcntl.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stdint.h>

#define MAP_SIZE   0x1000
#define CTRL_OFF   0x00
#define INOK_OFF   0x04
#define OUT_OFF    0x08

static inline void wr(fpga_dev_t* d, uint32_t off, uint32_t v) { d->base[off/4] = v; }
static inline uint32_t rd(fpga_dev_t* d, uint32_t off) { return d->base[off/4]; }

int fpga_open(fpga_dev_t* d, off_t phys_base) {
  d->fd = open("/dev/mem", O_RDWR | O_SYNC);
  if (d->fd < 0) return -1;
  void* map = mmap(NULL, MAP_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, d->fd, phys_base);
  if (map == MAP_FAILED) { close(d->fd); return -2; }
  d->base = (volatile uint32_t*)map;
  return 0;
}

void fpga_close(fpga_dev_t* d) {
  munmap((void*)d->base, MAP_SIZE);
  close(d->fd);
}

int fpga_validate(fpga_dev_t* d, uint32_t inok_mask, uint8_t* accept, uint8_t* rec) {
  wr(d, INOK_OFF, inok_mask);
  wr(d, CTRL_OFF, 0x1);
  wr(d, CTRL_OFF, 0x0);

  for (int i = 0; i < 200000; i++) {
    uint32_t out = rd(d, OUT_OFF);
    uint8_t done = (out >> 5) & 0x1;
    if (done) {
      *accept = (out >> 0) & 0x1;
      *rec    = (out >> 1) & 0xF;
      return 0;
    }
  }
  return -1;
}
