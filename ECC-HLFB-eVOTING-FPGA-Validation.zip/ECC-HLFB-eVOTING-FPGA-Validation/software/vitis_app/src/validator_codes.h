#pragma once
#include <stdint.h>

typedef enum {
  REC_OK          = 0,
  REC_CERT_FAIL   = 1,
  REC_SIG_FAIL    = 2,
  REC_TIME_FAIL   = 3,
  REC_REPLAY_FAIL = 4,
  REC_FMT_FAIL    = 5,
  REC_EP_FAIL     = 6
} rec_t;

static inline const char* rec_to_str(rec_t r) {
  switch (r) {
    case REC_OK:          return "OK";
    case REC_CERT_FAIL:   return "CERT_FAIL";
    case REC_SIG_FAIL:    return "SIG_FAIL";
    case REC_TIME_FAIL:   return "TIME_FAIL";
    case REC_REPLAY_FAIL: return "REPLAY_FAIL";
    case REC_FMT_FAIL:    return "FMT_FAIL";
    case REC_EP_FAIL:     return "EP_FAIL";
    default:              return "UNKNOWN";
  }
}
