#include <curl/curl.h>
#include <stdio.h>

int http_post_json(const char* url, const char* json) {
  CURL* curl = curl_easy_init();
  if (!curl) return -1;

  struct curl_slist* hdrs = NULL;
  hdrs = curl_slist_append(hdrs, "Content-Type: application/json");

  curl_easy_setopt(curl, CURLOPT_URL, url);
  curl_easy_setopt(curl, CURLOPT_HTTPHEADER, hdrs);
  curl_easy_setopt(curl, CURLOPT_POSTFIELDS, json);
  curl_easy_setopt(curl, CURLOPT_TIMEOUT, 5L);

  CURLcode res = curl_easy_perform(curl);
  curl_slist_free_all(hdrs);
  curl_easy_cleanup(curl);

  if (res != CURLE_OK) {
    fprintf(stderr, "curl error: %s
", curl_easy_strerror(res));
    return -2;
  }
  return 0;
}
