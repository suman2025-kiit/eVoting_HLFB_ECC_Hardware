#include <stdio.h>
#include <stdint.h>
#include <string.h>

#include "fpga_mmio.h"
#include "validator_codes.h"

int http_post_json(const char* url, const char* json);

// UPDATE: physical MMIO base from Vivado
#define FPGA_BASE_ADDR 0xA0000000

int main() {
  fpga_dev_t dev;
  if (fpga_open(&dev, FPGA_BASE_ADDR) != 0) {
    printf("ERROR: cannot open FPGA MMIO (/dev/mem).\n");
    return 1;
  }

  const char* GW = "http://<GATEWAY_IP>:8080";
  char url[160];

  // VALID case
  uint32_t inok_valid = 0;
  inok_valid |= (1u<<0); // cert_ok
  inok_valid |= (1u<<1); // sig_ok
  inok_valid |= (1u<<2); // time_ok
  inok_valid |= (1u<<3); // nonce_ok
  inok_valid |= (1u<<4); // fmt_ok
  inok_valid |= (1u<<5); // ep_ok

  uint8_t accept=0, rec=0;
  fpga_validate(&dev, inok_valid, &accept, &rec);
  printf("[VALID] CERT SIG TIME NONCE FMT EP OK\n");
  printf("Output Decision: %s\n", accept ? "ACCEPT" : "REJECT");

  if (accept) {
    snprintf(url, sizeof(url), "%s/api/submitVote", GW);
    const char* vote_json =
      "{ \"voterId\":\"HV_000A\", \"txId\":\"000A\", \"ballotHash\":\"0xABCD1234\", \"ts\":1730001111 }";
    http_post_json(url, vote_json);
  }

  // INVALID case: SIG_FAIL
  uint32_t inok_invalid = inok_valid & ~(1u<<1);
  fpga_validate(&dev, inok_invalid, &accept, &rec);
  printf("[INVALID] - Signature mismatch detected.\n");
  printf("Output Decision: %s\n", accept ? "ACCEPT" : "REJECT");
  printf("[FAIL] %s - Failed e-vote rejected with reason code.\n", rec_to_str((rec_t)rec));

  snprintf(url, sizeof(url), "%s/api/logReject", GW);
  char rej_json[256];
  snprintf(rej_json, sizeof(rej_json),
    "{ \"voterId\":\"HV_000B\", \"txId\":\"000B\", \"reason\":\"%s\", \"ts\":1730002222 }",
    rec_to_str((rec_t)rec));
  http_post_json(url, rej_json);

  fpga_close(&dev);
  return 0;
}
