#pragma once
#include <stdint.h>
#include <sys/types.h>

typedef struct {
  volatile uint32_t* base;
  int fd;
} fpga_dev_t;

int  fpga_open(fpga_dev_t* d, off_t phys_base);
void fpga_close(fpga_dev_t* d);
int  fpga_validate(fpga_dev_t* d, uint32_t inok_mask, uint8_t* accept, uint8_t* rec);
